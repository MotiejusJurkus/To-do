To-do list app.

Description: Keep track of your tasks and the ones you have finished.

Features: -

Technologies Used: Mention HTML, CSS, JavaScript.

Setup Instructions: -

Live Demo: Include a link if hosted online (e.g., GitHub Pages, Netlify).​